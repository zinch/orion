package com.acme.orion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrionApplicationTests {

  @Test
  void contextLoads() {
  }

}
